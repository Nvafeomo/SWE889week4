# Supplier Agent Assignment Submission

This folder contains the verified comparison run and the implementation changes for the multi-agent supplier assignment.

What changed:
- Completed the Buyer Agent criteria prompt so quantity and deadline are stated explicitly.
- Completed the Supplier Analysis Agent prompt so it rejects suppliers that fail the quantity or deadline constraints.
- Implemented the Buyer Agent risk check so impossible recommendations are flagged before the answer is returned.
- Improved the final response format to show the selected supplier and warnings clearly.

Files:
- baseline-output.txt: starter-system output before the fix
- test-output.txt: modified-system output after the fix
- uml-diagrams.md: use case and sequence diagrams
- reflection.md: short design reflection

Run locally:
```bash
cd week4/2-supplier-agents
docker compose up -d ollama
docker compose run --rm agent-app
```
